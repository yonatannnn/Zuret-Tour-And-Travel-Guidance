const humberger = document.getElementById('humberger')

const nav_list = document.getElementById('nav-list')

const active  = window.location.pathname









humberger.addEventListener('click', function(){

    nav_list.classList.toggle('nav__list--show')
    

})


















    
    



